package br.com.edubarbieri.guasca.ingestion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GuascaIngestionApplicationTests {

	@Test
	void contextLoads() {
	}

}
